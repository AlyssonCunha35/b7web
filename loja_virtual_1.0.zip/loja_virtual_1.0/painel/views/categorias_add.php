<h1>Categorias - Adicionar</h1>
<form method="POST">

	<input type="text" name="titulo" placeholder="Titulo da categoria" class="form-control" /><br/>

	<input type="submit" value="Salvar" class="btn btn-default" />

</form>