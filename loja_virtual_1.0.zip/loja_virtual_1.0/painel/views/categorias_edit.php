<h1>Categorias - Editar</h1>
<form method="POST">

	<input type="text" name="titulo" value="<?php echo $categoria['titulo']; ?>" placeholder="Titulo da categoria" class="form-control" /><br/>

	<input type="submit" value="Salvar" class="btn btn-default" />

</form>