<h1><?php echo $categorias; ?></h1>

