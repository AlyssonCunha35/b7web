<!DOCTYPE html>
<html>
<head>
	<title>Nossa Loja</title>
	<link rel="stylesheet"  href="/loja_virtual_1.0/assets/css/template.css">
</head>
<body>

	<div class="topo"></div>
	<div class="menu">
		<div class="menuint">

			<ul>
				<a href="/loja_virtual_1.0"><li>Home</li></a>
				<a href="/loja_virtual_1.0/empresa"><li>Empresa</li></a>
				<?php foreach ($menu as $menuitem) :?>

					<a href="/loja_virtual_1.0/categoria/ver/<?php echo $menuitem['id']; ?>"><li><?php echo $menuitem['titulo']; ?></li></a>

				<?php endforeach; ?>

				<a href="/contato"><li>Contato</li></a>
			</ul>
		</div>
	</div>
	<div class="container">
		
		<?php $this->loadViewInTemplate($viewName, $viewData) ?>


	</div>
	<div class="rodape"></div>




</body>
</html>