<!DOCTYPE html>
<html>
<head>
	<title>Nossa Loja</title>
	<link rel="stylesheet" href="assets/css/template.css">
</head>
<body>
	<div class="topo"></div>
	<div class="menu">
		<div class="menuint">
			<ul>
				<a href="/loja_virtual_1.0"><li>Home</li></a>
				<a href="/loja_virtual_1.0/empresa"><li>Empresa</li></a>
				<?php foreach ($menu as $menuitem):?>

					<a href="<?php echo BASE."ver/"?><?php echo $menuitem['id']; ?>"><li><?php echo $menuitem['titulo']; ?></li></a>

					<?php endforeach; ?>

				<li>Contato</li>
			</ul>
		</div>
	</div>
	<div class="container">
		<?php $this->loadViewInTemplate($viewName, $viewData); ?>
	</div>
	<div class="rodape"></div>

</body>
</html>