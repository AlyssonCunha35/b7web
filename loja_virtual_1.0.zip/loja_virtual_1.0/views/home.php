<?php 

foreach ($produtos as $produto): ?> 
		<div class="produto">
			<a href="<?php echo BASE."ver/"?><?php echo $produto['id']; ?>">

			<img src="" width="180" height="180" border="none">
			<strong> <?php echo $produto['nome']; ?> </strong> <br/>
			<?php echo 'R$ '.$produto['preco']; ?>

		</div>
	</a>

<?php endforeach; ?>

<div style="clear: both;"></div> <!-- Calcula quando há muitos float left -->


