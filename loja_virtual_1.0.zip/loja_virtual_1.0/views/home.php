<?php 

foreach ($produtos as $produto) : ?>
<a href="/produto/ver/<?php echo $produto['id']; ?>">
<div class="produto">
	<img src=""	width="180" height="180" border="0" alt="">
	
	<strong><?php echo $produto['nome']; ?></strong><br/>
	<?php echo 'R$ '.$produto['preco'] ?>

</div>

</a>

<?php endforeach; ?>

<div style="clear: both;"></div>