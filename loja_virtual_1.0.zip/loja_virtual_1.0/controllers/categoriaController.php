<?php 

class categoriaController extends controller {
    
	public function __construct() {
		parent::__construct();
	}


	public function ver($id) {

		$dados = array();



		$this->loadTemplate("categoria", $dados);

	}

}


 ?>