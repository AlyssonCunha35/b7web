<?php
define("ENVIRONMENT", "development");
?>