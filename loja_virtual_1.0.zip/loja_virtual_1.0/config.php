<?php
require 'environment.php';

define('BASE', 'http://localhost/loja_virtual_1.0/');

global $config;
$config = array();
if(ENVIRONMENT == 'development') {
	$config['dbname'] = 'loja_virtual_1.0';
	$config['host'] = 'localhost';
	$config['dbuser'] = 'root';
	$config['dbpass'] = '';
} else {
	$config['dbname'] = 'loja_virtual_1.0';
	$config['host'] = 'localhost';
	$config['dbuser'] = 'root';
	$config['dbpass'] = '';
}


?>